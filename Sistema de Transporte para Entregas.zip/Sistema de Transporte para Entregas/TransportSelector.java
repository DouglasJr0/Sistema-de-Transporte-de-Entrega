public class TransportSelector {
    public String selectAndDeliver(PackageInfo pkg, DestinationInfo destination) {
        // Use a fábrica para obter a estratégia correta
        TransportStrategy strategy = TransportFactory.getTransportStrategy(pkg, destination);
        return strategy.deliver(pkg, destination);
    }
}
