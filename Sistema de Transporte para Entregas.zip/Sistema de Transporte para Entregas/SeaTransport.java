public class SeaTransport implements TransportStrategy {
    @Override
    public String deliver(PackageInfo pkg, DestinationInfo destination) {
        if (!destination.isInternational()) {
            return "Transporte marítimo é apenas para entregas internacionais.";
        }
        return "Entregando por transporte marítimo para " + destination.getLocation() + ".";
    }
}
