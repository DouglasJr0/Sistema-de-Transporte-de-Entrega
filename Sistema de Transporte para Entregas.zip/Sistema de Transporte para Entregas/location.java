public class DestinationInfo {
    private String location;
    private boolean isInternational;
    private boolean isMetropolitan;

    public DestinationInfo(String location, boolean isInternational, boolean isMetropolitan) {
        this.location = location;
        this.isInternational = isInternational;
        this.isMetropolitan = isMetropolitan;
    }

    public String getLocation() {
        return location;
    }

    public boolean isInternational() {
        return isInternational;
    }

    public boolean isMetropolitan() {
        return isMetropolitan;
    }
}
