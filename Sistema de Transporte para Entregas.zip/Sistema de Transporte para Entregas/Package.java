public class PackageInfo {
    private double weight;
    private Dimensions dimensions;

    public PackageInfo(double weight, Dimensions dimensions) {
        this.weight = weight;
        this.dimensions = dimensions;
    }

    public double getWeight() {
        return weight;
    }

    public Dimensions getDimensions() {
        return dimensions;
    }
}

class Dimensions {
    private double length, width, height;

    public Dimensions(double length, double width, double height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    public boolean exceeds(double maxLength, double maxWidth, double maxHeight) {
        return length > maxLength || width > maxWidth || height > maxHeight;
    }
}
