public class AirTransport implements TransportStrategy {
    @Override
    public String deliver(PackageInfo pkg, DestinationInfo destination) {
        if (pkg.getWeight() > 20 || pkg.getDimensions().exceeds(50, 50, 50)) {
            return "Pacote excede os limites de peso ou dimensão para transporte aéreo.";
        }
        return "Entregando por transporte aéreo para " + destination.getLocation() + ".";
    }
}
